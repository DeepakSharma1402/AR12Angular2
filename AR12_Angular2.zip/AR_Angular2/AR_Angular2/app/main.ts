﻿import {enableProdMode} from '@angular/core';
import {bootstrap}    from '@angular/platform-browser-dynamic'
import {Html5ViewerComponent} from './components/viewer/html5viewercomponent';

//enableProdMode();
bootstrap(Html5ViewerComponent);