﻿import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'html5viewer',
    templateUrl: './app/components/viewer/html5viewertemplate.html'
})

export class Html5ViewerComponent implements OnInit {

    initializeHtml5Viewer() {

        var viewer = GrapeCity.ActiveReports.Viewer({
            element: '#Viewer',
            reportService: {
                url: './app/ActiveReports.ReportService.asmx'
            },
            uiType: 'desktop',           
            documentLoaded: function () {
                console.log(viewer.pageCount);
            },
            error: function (error) {
                console.log("error");
            }
        });       

        var reportOption = {           
            id: './app/Reports/BillingInvoice.rdlx'
        };
        
        viewer.option('report', reportOption);
    }

    ngOnInit() {
        this.initializeHtml5Viewer();
    }
}