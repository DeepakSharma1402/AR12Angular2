"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var html5viewercomponent_1 = require("./components/viewer/html5viewercomponent");
//enableProdMode();
platform_browser_dynamic_1.bootstrap(html5viewercomponent_1.Html5ViewerComponent);
//# sourceMappingURL=main.js.map