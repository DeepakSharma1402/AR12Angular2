/// <reference path="main/ambient/TypeLite/index.d.ts" />
/// <reference path="main/ambient/bootstrap/index.d.ts" />
/// <reference path="main/ambient/core-js/index.d.ts" />
/// <reference path="main/ambient/jquery/index.d.ts" />
